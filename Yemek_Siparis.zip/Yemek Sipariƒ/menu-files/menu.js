
var urunSepeti = [];
var urunMiktari = [];

const sepeteEkle = (deger) => {

var urunAdi = document.getElementsByClassName("baslik")[deger].textContent;
var urunAdedi = document.getElementsByClassName("miktar")[deger].value;

if(urunAdedi<=0) alert("Lütfen gerçekçi değerler giriniz. Sipariş miktarı 0 ya da negatif olamaz!");

else {
    var icerik ="";
    if(urunSepeti.includes(urunAdi,deger)) 
        { 
        urunMiktari[deger]=urunAdedi; 
        for(var i=0; i<urunSepeti.length; i++)
            {   if(urunSepeti[i]==undefined) continue;
             icerik +=urunSepeti[i]+" - "+urunMiktari[i]+" TANE<br/>";
            }
        }

    else{
        urunSepeti[deger]=urunAdi;
        urunMiktari[deger]=urunAdedi;
        for(var i=0; i<urunSepeti.length; i++)
        {     if(urunSepeti[i]==undefined) continue;
           icerik +=urunSepeti[i]+"  - "+urunMiktari[i]+" TANE<br/>";
        }
        
     }

document.getElementById("SEPET").innerHTML="<br/>"+icerik;
}                           
}

function odemeButton() {
    
}
/*
const path = require('path');
yemekSiparis = path.parse(__dirname);

const a = require(yemekSiparis.dir+"/server.js");

function odemeButton() {
    a.odeme();
}

/*
const path = require('path');
//console.log(path.parse(__dirname));
yemekSiparis = path.parse(__dirname);
console.log(yemekSiparis.dir);

const odeme = require(yemekSiparis.dir+"/server.js");

odeme();

*/



//icerik=icerik+'<br/>'+urunAdi+" "+urunAdedi+" TANE";
//document.getElementById("SEPET").innerHTML=icerik;