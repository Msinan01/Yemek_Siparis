const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();

//app.use(express.static(path.join(__dirname,'/anamenu-files')));
//app.use(express.static(path.join(__dirname,'/odeme-files')));
app.use(express.static(path.join(__dirname)));

app.listen(8080,()=>{
    console.log("***  Connected the server.  ***")});


const anamenu = app.get("/",(req,res)=>{
    fs.readFile("anamenu.html",(err,data)=>{
        res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});
        if(err) console.log("\n\n***  Something went wront!\n"+err+"\n");

        else{
        console.log("***  Server access provided. ***");
        res.end(data);
        }
    });
});


const menu = app.get('/menu',(request,response)=>{
    response.writeHead(200,{'Content-Type' : 'text/html; charset=utf-8'});
    fs.readFile("menu.html",(error,data)=>{
    
        if(error) console.log("\n\n***  Something went wront!\n"+error+"\n");
        
        else {
        console.log("***  Server access provided. ***");
        response.end(data);

    }});
});


const odeme = app.get("/odeme", (request,response)=>{
            response.writeHead(200,{'Content-Type' : 'text/html; charset=utf-8'});

            fs.readFile("odeme.html",(error,data)=>{
        if(error) console.log("\n\n***  Something went wront!\n"+error+"\n"); 
    
        else{
            console.log("***  Server access provided that odeme ***\n    Odeme.html");
            response.end(data);
        }
    });
});



